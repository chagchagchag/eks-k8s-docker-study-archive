package dev.k8s.backend.fibonacci_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FibonacciBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
