package dev.k8s.backend.fibonacci_backend_cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FibonacciBackendCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
