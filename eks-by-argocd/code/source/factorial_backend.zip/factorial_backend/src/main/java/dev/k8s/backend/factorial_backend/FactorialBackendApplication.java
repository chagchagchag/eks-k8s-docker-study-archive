package dev.k8s.backend.factorial_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactorialBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactorialBackendApplication.class, args);
	}

}
