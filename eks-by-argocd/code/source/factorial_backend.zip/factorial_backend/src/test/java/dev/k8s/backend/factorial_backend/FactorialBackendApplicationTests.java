package dev.k8s.backend.factorial_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FactorialBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
